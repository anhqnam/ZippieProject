package com.example.sdktest;

import unique.packagename.features.profile.UserProfile;
import unique.packagename.sdkwrapper.profile.ProfileWrapper;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class ProfileActivity extends ActionBarActivity {
	
	Button getProfile;
	TextView showProfile;
	
	ProfileWrapper mPW = new ProfileWrapper();
	
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        
        getProfile = (Button) findViewById(R.id.button1);
        showProfile = (TextView) findViewById(R.id.textView1);
        
        getProfile.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				new Thread(new Runnable() {
					
					@Override
					public void run() {
						final UserProfile profile = mPW.getProfile();
						runOnUiThread(new Runnable() {
							
							@Override
							public void run() {
								if(profile != null){
									showProfile.setText(profile.toString());									
								}
							}
						});
						
					}
				}).start();
			}
		});
	}
}
